import os
import zipfile

print("=== File Operations Demo ===")

# Show current working directory
print(f"Current working directory: {os.getcwd()}")

# Create some sample files and directories
print("\n1. Creating sample files and directories...")

# Create a test directory
test_dir = 'sample_project'
if not os.path.exists(test_dir):
    os.makedirs(test_dir)
    print(f"✓ Created directory: {test_dir}")

# Create subdirectories
subdirs = ['docs', 'src', 'tests']
for subdir in subdirs:
    subdir_path = os.path.join(test_dir, subdir)
    if not os.path.exists(subdir_path):
        os.makedirs(subdir_path)
        print(f"✓ Created subdirectory: {subdir_path}")

# Create sample files with content
sample_files = {
    os.path.join(test_dir, 'README.md'): '# Sample Project\nThis is a demo project.',
    os.path.join(test_dir, 'src', 'main.py'): 'print("Hello, World!")\n',
    os.path.join(test_dir, 'src', 'utils.py'): 'def helper_function():\n    return "Helper"',
    os.path.join(test_dir, 'docs', 'guide.txt'): 'User guide content here.',
    os.path.join(test_dir, 'tests', 'test_main.py'): 'import unittest\n\nclass TestMain(unittest.TestCase):\n    pass'
}

for file_path, content in sample_files.items():
    with open(file_path, 'w') as f:
        f.write(content)
    print(f"✓ Created file: {file_path}")

print(f"\n2. Listing contents of {test_dir}:")
for root, dirs, files in os.walk(test_dir):
    level = root.replace(test_dir, '').count(os.sep)
    indent = ' ' * 2 * level
    print(f"{indent}{os.path.basename(root)}/")
    subindent = ' ' * 2 * (level + 1)
    for file in files:
        print(f"{subindent}{file}")

# Create ZIP archive
print("\n3. Creating ZIP archive...")
zip_name = 'sample_project.zip'

def create_zip_archive(folder_path, zip_name):
    """Create a ZIP archive from a folder"""
    with zipfile.ZipFile(zip_name, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(folder_path):
            for file in files:
                file_path = os.path.join(root, file)
                # Create relative path for archive
                arcname = os.path.relpath(file_path, os.path.dirname(folder_path))
                zipf.write(file_path, arcname)
                print(f"  Added to archive: {arcname}")
    return zip_name

archive_path = create_zip_archive(test_dir, zip_name)
print(f"✓ Created ZIP archive: {archive_path}")

# List ZIP contents
print(f"\n4. Contents of {zip_name}:")
def list_zip_contents(zip_name):
    """List contents of a ZIP file"""
    with zipfile.ZipFile(zip_name, 'r') as zipf:
        for info in zipf.infolist():
            size_kb = info.file_size / 1024 if info.file_size > 0 else 0
            print(f"  {info.filename} - {info.file_size} bytes ({size_kb:.2f} KB)")

list_zip_contents(zip_name)

# Extract to new location
print(f"\n5. Extracting {zip_name} to 'extracted_files'...")
extract_dir = 'extracted_files'

def extract_zip_archive(zip_name, extract_to):
    """Extract a ZIP archive to a specified directory"""
    if not os.path.exists(extract_to):
        os.makedirs(extract_to)
    
    with zipfile.ZipFile(zip_name, 'r') as zipf:
        zipf.extractall(extract_to)
        extracted_files = zipf.namelist()
    
    print(f"✓ Extracted {len(extracted_files)} files to {extract_to}")
    return extracted_files

extracted_files = extract_zip_archive(zip_name, extract_dir)

# Verify extraction
print(f"\n6. Verifying extraction in {extract_dir}:")
for root, dirs, files in os.walk(extract_dir):
    level = root.replace(extract_dir, '').count(os.sep)
    indent = ' ' * 2 * level
    print(f"{indent}{os.path.basename(root)}/")
    subindent = ' ' * 2 * (level + 1)
    for file in files:
        file_path = os.path.join(root, file)
        file_size = os.path.getsize(file_path)
        print(f"{subindent}{file} ({file_size} bytes)")

# Get file statistics
print(f"\n7. File system statistics:")
zip_size = os.path.getsize(zip_name)
print(f"ZIP archive size: {zip_size} bytes ({zip_size/1024:.2f} KB)")

# Count total files in original directory
total_files = 0
total_size = 0
for root, dirs, files in os.walk(test_dir):
    total_files += len(files)
    for file in files:
        total_size += os.path.getsize(os.path.join(root, file))

print(f"Original directory: {total_files} files, {total_size} bytes ({total_size/1024:.2f} KB)")
compression_ratio = (1 - zip_size/total_size) * 100 if total_size > 0 else 0
print(f"Compression ratio: {compression_ratio:.1f}%")

print("\n=== Demo completed successfully! ===")
