"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { FolderIcon, FileIcon, DownloadIcon, UploadIcon, PlusIcon, TrashIcon, ArchiveIcon } from "lucide-react"

interface FileItem {
  name: string
  type: "file" | "folder"
  content?: string
  size?: number
  children?: FileItem[]
}

export default function FileManagerApp() {
  const [fileSystem, setFileSystem] = useState<FileItem[]>([])
  const [currentPath, setCurrentPath] = useState<string[]>([])
  const [newFileName, setNewFileName] = useState("")
  const [newFileContent, setNewFileContent] = useState("")
  const [newFolderName, setNewFolderName] = useState("")
  const [zipFiles, setZipFiles] = useState<{ [key: string]: Blob }>({})
  const [logs, setLogs] = useState<string[]>(["=== File Manager Demo Started ==="])
  const fileInputRef = useRef<HTMLInputElement>(null)

  const addLog = (message: string) => {
    setLogs((prev) => [...prev, `${new Date().toLocaleTimeString()}: ${message}`])
  }

  const getCurrentDirectory = (): FileItem[] => {
    let current = fileSystem
    for (const pathPart of currentPath) {
      const folder = current.find((item) => item.name === pathPart && item.type === "folder")
      if (folder && folder.children) {
        current = folder.children
      }
    }
    return current
  }

  const updateFileSystem = (updater: (current: FileItem[]) => FileItem[]) => {
    setFileSystem((prev) => {
      const updateAtPath = (items: FileItem[], path: string[]): FileItem[] => {
        if (path.length === 0) {
          return updater(items)
        }

        return items.map((item) => {
          if (item.name === path[0] && item.type === "folder") {
            return {
              ...item,
              children: updateAtPath(item.children || [], path.slice(1)),
            }
          }
          return item
        })
      }

      return updateAtPath(prev, currentPath)
    })
  }

  const createSampleProject = () => {
    const sampleProject: FileItem[] = [
      {
        name: "sample_project",
        type: "folder",
        children: [
          {
            name: "README.md",
            type: "file",
            content: "# Sample Project\nThis is a demo project.",
            size: 42,
          },
          {
            name: "src",
            type: "folder",
            children: [
              {
                name: "main.py",
                type: "file",
                content: 'print("Hello, World!")\n',
                size: 23,
              },
              {
                name: "utils.py",
                type: "file",
                content: 'def helper_function():\n    return "Helper"',
                size: 45,
              },
            ],
          },
          {
            name: "docs",
            type: "folder",
            children: [
              {
                name: "guide.txt",
                type: "file",
                content: "User guide content here.",
                size: 25,
              },
            ],
          },
          {
            name: "tests",
            type: "folder",
            children: [
              {
                name: "test_main.py",
                type: "file",
                content: "import unittest\n\nclass TestMain(unittest.TestCase):\n    pass",
                size: 65,
              },
            ],
          },
        ],
      },
    ]

    setFileSystem(sampleProject)
    setCurrentPath([])
    addLog("✓ Created sample project structure")
    addLog("✓ Created directory: sample_project")
    addLog("✓ Created subdirectories: src, docs, tests")
    addLog("✓ Created 5 sample files with content")
  }

  const createFile = () => {
    if (!newFileName.trim()) return

    updateFileSystem((current) => [
      ...current,
      {
        name: newFileName,
        type: "file",
        content: newFileContent,
        size: newFileContent.length,
      },
    ])

    addLog(`✓ Created file: ${[...currentPath, newFileName].join("/")}`)
    setNewFileName("")
    setNewFileContent("")
  }

  const createFolder = () => {
    if (!newFolderName.trim()) return

    updateFileSystem((current) => [
      ...current,
      {
        name: newFolderName,
        type: "folder",
        children: [],
      },
    ])

    addLog(`✓ Created folder: ${[...currentPath, newFolderName].join("/")}`)
    setNewFolderName("")
  }

  const deleteItem = (name: string) => {
    updateFileSystem((current) => current.filter((item) => item.name !== name))
    addLog(`✓ Deleted: ${[...currentPath, name].join("/")}`)
  }

  const navigateToFolder = (folderName: string) => {
    setCurrentPath((prev) => [...prev, folderName])
  }

  const navigateUp = () => {
    setCurrentPath((prev) => prev.slice(0, -1))
  }

  const getAllFiles = (items: FileItem[], basePath = ""): Array<{ path: string; content: string; size: number }> => {
    const files: Array<{ path: string; content: string; size: number }> = []

    for (const item of items) {
      const itemPath = basePath ? `${basePath}/${item.name}` : item.name

      if (item.type === "file" && item.content !== undefined) {
        files.push({
          path: itemPath,
          content: item.content,
          size: item.size || 0,
        })
      } else if (item.type === "folder" && item.children) {
        files.push(...getAllFiles(item.children, itemPath))
      }
    }

    return files
  }

  const createZipArchive = async () => {
    const currentDir = getCurrentDirectory()
    if (currentDir.length === 0) {
      addLog("❌ No files to archive")
      return
    }

    // Simple ZIP creation simulation
    const files = getAllFiles(currentDir)
    const zipContent = files.map((file) => `${file.path}: ${file.content}`).join("\n---\n")
    const blob = new Blob([zipContent], { type: "application/zip" })

    const zipName = currentPath.length > 0 ? `${currentPath[currentPath.length - 1]}.zip` : "archive.zip"
    setZipFiles((prev) => ({ ...prev, [zipName]: blob }))

    addLog(`✓ Created ZIP archive: ${zipName}`)
    addLog(`  Added ${files.length} files to archive`)
    files.forEach((file) => addLog(`  Added to archive: ${file.path}`))

    const totalSize = files.reduce((sum, file) => sum + file.size, 0)
    const compressionRatio = (((totalSize - blob.size) / totalSize) * 100).toFixed(1)
    addLog(`Original size: ${totalSize} bytes, ZIP size: ${blob.size} bytes`)
    addLog(`Compression ratio: ${compressionRatio}%`)
  }

  const downloadZip = (zipName: string) => {
    const blob = zipFiles[zipName]
    if (!blob) return

    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = zipName
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)

    addLog(`✓ Downloaded: ${zipName}`)
  }

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files
    if (!files) return

    Array.from(files).forEach((file) => {
      const reader = new FileReader()
      reader.onload = (e) => {
        const content = e.target?.result as string
        updateFileSystem((current) => [
          ...current,
          {
            name: file.name,
            type: "file",
            content: content,
            size: file.size,
          },
        ])
        addLog(`✓ Uploaded file: ${file.name} (${file.size} bytes)`)
      }
      reader.readAsText(file)
    })
  }

  const formatBytes = (bytes: number) => {
    if (bytes === 0) return "0 B"
    const k = 1024
    const sizes = ["B", "KB", "MB"]
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return Number.parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i]
  }

  const currentDir = getCurrentDirectory()
  const breadcrumb = currentPath.length > 0 ? currentPath.join(" / ") : "Root"

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-6xl mx-auto space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FolderIcon className="h-6 w-6" />
              File Manager & ZIP Utility
            </CardTitle>
            <p className="text-sm text-gray-600">
              Web implementation of file operations with ZIP archive functionality
            </p>
          </CardHeader>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>File Browser</CardTitle>
                    <p className="text-sm text-gray-600">Current: {breadcrumb}</p>
                  </div>
                  <div className="flex gap-2">
                    <Button onClick={createSampleProject} variant="outline" size="sm">
                      <PlusIcon className="h-4 w-4 mr-1" />
                      Create Sample
                    </Button>
                    {currentPath.length > 0 && (
                      <Button onClick={navigateUp} variant="outline" size="sm">
                        ← Back
                      </Button>
                    )}
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 max-h-64 overflow-y-auto">
                  {currentDir.length === 0 ? (
                    <p className="text-gray-500 text-center py-8">
                      No files or folders. Create a sample project to get started.
                    </p>
                  ) : (
                    currentDir.map((item, index) => (
                      <div
                        key={index}
                        className="flex items-center justify-between p-2 rounded border hover:bg-gray-50"
                      >
                        <div
                          className="flex items-center gap-2 cursor-pointer flex-1"
                          onClick={() => item.type === "folder" && navigateToFolder(item.name)}
                        >
                          {item.type === "folder" ? (
                            <FolderIcon className="h-4 w-4 text-blue-500" />
                          ) : (
                            <FileIcon className="h-4 w-4 text-gray-500" />
                          )}
                          <span className="font-medium">{item.name}</span>
                          {item.type === "file" && item.size && (
                            <Badge variant="secondary" className="text-xs">
                              {formatBytes(item.size)}
                            </Badge>
                          )}
                        </div>
                        <Button
                          onClick={() => deleteItem(item.name)}
                          variant="ghost"
                          size="sm"
                          className="text-red-500 hover:text-red-700"
                        >
                          <TrashIcon className="h-4 w-4" />
                        </Button>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>

            <Tabs defaultValue="create" className="w-full">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="create">Create</TabsTrigger>
                <TabsTrigger value="upload">Upload</TabsTrigger>
                <TabsTrigger value="archive">Archive</TabsTrigger>
                <TabsTrigger value="extract">Extract</TabsTrigger>
              </TabsList>

              <TabsContent value="create" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Create New Items</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Create File</label>
                      <Input
                        placeholder="File name (e.g., script.py)"
                        value={newFileName}
                        onChange={(e) => setNewFileName(e.target.value)}
                      />
                      <Textarea
                        placeholder="File content..."
                        value={newFileContent}
                        onChange={(e) => setNewFileContent(e.target.value)}
                        rows={3}
                      />
                      <Button onClick={createFile} disabled={!newFileName.trim()}>
                        <FileIcon className="h-4 w-4 mr-1" />
                        Create File
                      </Button>
                    </div>

                    <Separator />

                    <div className="space-y-2">
                      <label className="text-sm font-medium">Create Folder</label>
                      <Input
                        placeholder="Folder name"
                        value={newFolderName}
                        onChange={(e) => setNewFolderName(e.target.value)}
                      />
                      <Button onClick={createFolder} disabled={!newFolderName.trim()}>
                        <FolderIcon className="h-4 w-4 mr-1" />
                        Create Folder
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="upload">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Upload Files</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <input ref={fileInputRef} type="file" multiple onChange={handleFileUpload} className="hidden" />
                    <Button onClick={() => fileInputRef.current?.click()}>
                      <UploadIcon className="h-4 w-4 mr-1" />
                      Select Files to Upload
                    </Button>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="archive">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Create ZIP Archive</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <Button onClick={createZipArchive} disabled={currentDir.length === 0}>
                      <ArchiveIcon className="h-4 w-4 mr-1" />
                      Create ZIP from Current Directory
                    </Button>

                    {Object.keys(zipFiles).length > 0 && (
                      <div className="space-y-2">
                        <h4 className="font-medium">Available ZIP Files:</h4>
                        {Object.keys(zipFiles).map((zipName) => (
                          <div key={zipName} className="flex items-center justify-between p-2 border rounded">
                            <span>{zipName}</span>
                            <Button onClick={() => downloadZip(zipName)} size="sm">
                              <DownloadIcon className="h-4 w-4 mr-1" />
                              Download
                            </Button>
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="extract">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Extract Archives</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-600">
                      Archive extraction functionality would be implemented here. In a real application, this would
                      handle ZIP file uploads and extraction.
                    </p>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>

          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Activity Log</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-1 max-h-96 overflow-y-auto text-xs font-mono">
                  {logs.map((log, index) => (
                    <div key={index} className="text-gray-700">
                      {log}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Statistics</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm">Total Files:</span>
                  <Badge>{getAllFiles(fileSystem).length}</Badge>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">ZIP Archives:</span>
                  <Badge>{Object.keys(zipFiles).length}</Badge>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Current Directory:</span>
                  <Badge>{currentDir.length} items</Badge>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
