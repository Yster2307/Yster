# Ads Platform

React/Next.js + Firebase + Netlify-ready platform for posting ads.

## Deployment
- Configure Firebase in `.env`
- Push to GitHub
- Deploy on Netlify using build: `npm run build && npm run export`, output: `out`