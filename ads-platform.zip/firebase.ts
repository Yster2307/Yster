// firebase.ts - Firebase config with security hardening for Netlify
import { initializeApp } from 'firebase/app';
import {
  getAuth,
  GoogleAuthProvider,
  signInWithPopup,
  signOut,
  onAuthStateChanged,
} from 'firebase/auth';
import {
  getFirestore,
  collection,
  addDoc,
  serverTimestamp,
  query,
  orderBy,
  getDocs,
  where,
  doc,
  getDoc,
  updateDoc,
  deleteDoc,
} from 'firebase/firestore';
import {
  getStorage,
  ref,
  uploadBytes,
  getDownloadURL,
} from 'firebase/storage';

const firebaseConfig = {
  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY,
  authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
  storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID,
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);

const provider = new GoogleAuthProvider();

export const signInWithGoogle = async () => {
  try {
    const result = await signInWithPopup(auth, provider);
    return result.user;
  } catch (error) {
    console.error('Google Sign-in error', error);
    throw new Error('Failed to sign in.');
  }
};

export const logout = async () => {
  try {
    await signOut(auth);
  } catch (error) {
    console.error('Sign-out error', error);
    throw new Error('Failed to log out.');
  }
};

export const onUserStateChange = (callback: (user: any) => void) => {
  onAuthStateChanged(auth, callback);
};

// Firestore secured ad posting
export const postAd = async (userId: string, title: string, description: string, imageUrl: string) => {
  if (!userId || !title || !description) throw new Error('Invalid data');
  const adData = {
    userId,
    title: title.trim(),
    description: description.trim(),
    imageUrl,
    createdAt: serverTimestamp(),
  };
  return await addDoc(collection(db, 'ads'), adData);
};

export const getUserAds = async (userId: string) => {
  const q = query(collection(db, 'ads'), where('userId', '==', userId), orderBy('createdAt', 'desc'));
  const snapshot = await getDocs(q);
  return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
};

export const updateAd = async (userId: string, adId: string, updates: any) => {
  const adRef = doc(db, 'ads', adId);
  const adSnap = await getDoc(adRef);
  if (!adSnap.exists() || adSnap.data().userId !== userId) throw new Error('Unauthorized');
  return await updateDoc(adRef, updates);
};

export const deleteAd = async (userId: string, adId: string) => {
  const adRef = doc(db, 'ads', adId);
  const adSnap = await getDoc(adRef);
  if (!adSnap.exists() || adSnap.data().userId !== userId) throw new Error('Unauthorized');
  return await deleteDoc(adRef);
};

export const uploadAdImage = async (file: File, userId: string) => {
  if (!file || !userId) throw new Error('Missing file or user');
  const storageRef = ref(storage, `ads/${userId}/${Date.now()}-${file.name}`);
  await uploadBytes(storageRef, file);
  return await getDownloadURL(storageRef);
};
