const nextConfig = {
  reactStrictMode: true,
  output: 'export',
};
module.exports = nextConfig;
